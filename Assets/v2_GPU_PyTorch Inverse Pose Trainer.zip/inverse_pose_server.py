#!/usr/bin/env python3
"""
Inverse Pose Inference Server

Loads a trained model and serves predictions over TCP.
Unity sends an image, Python returns predicted rotation.

Usage:
    python inverse_pose_server.py --model inverse_pose_final.pt --port 5556
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import socket
import struct
import argparse
import time


class InversePoseNet(nn.Module):
    """Same architecture as trainer - must match exactly."""
    
    def __init__(self, image_size=128):
        super().__init__()
        
        self.conv1 = nn.Conv2d(4, 32, 5, stride=2, padding=2)
        self.conv2 = nn.Conv2d(32, 64, 5, stride=2, padding=2)
        self.conv3 = nn.Conv2d(64, 128, 3, stride=2, padding=1)
        self.conv4 = nn.Conv2d(128, 256, 3, stride=2, padding=1)
        self.conv5 = nn.Conv2d(256, 512, 3, stride=2, padding=1)
        
        self.bn1 = nn.BatchNorm2d(32)
        self.bn2 = nn.BatchNorm2d(64)
        self.bn3 = nn.BatchNorm2d(128)
        self.bn4 = nn.BatchNorm2d(256)
        self.bn5 = nn.BatchNorm2d(512)
        
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        
        self.fc1 = nn.Linear(512, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 3)
        
        self.dropout = nn.Dropout(0.3)
    
    def forward(self, x):
        x = F.leaky_relu(self.bn1(self.conv1(x)), 0.2)
        x = F.leaky_relu(self.bn2(self.conv2(x)), 0.2)
        x = F.leaky_relu(self.bn3(self.conv3(x)), 0.2)
        x = F.leaky_relu(self.bn4(self.conv4(x)), 0.2)
        x = F.leaky_relu(self.bn5(self.conv5(x)), 0.2)
        
        x = self.global_pool(x)
        x = x.view(x.size(0), -1)
        
        x = F.leaky_relu(self.fc1(x), 0.2)
        x = self.dropout(x)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = self.dropout(x)
        x = self.fc3(x)
        
        x = torch.sigmoid(x)
        
        return x


def serve(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Load model
    print(f"Loading model from {args.model}...")
    checkpoint = torch.load(args.model, map_location=device)
    
    image_size = checkpoint.get('image_size', args.image_size)
    model = InversePoseNet(image_size).to(device)
    model.load_state_dict(checkpoint['model_state'])
    model.eval()
    print(f"Model loaded! Image size: {image_size}x{image_size}")
    
    # Setup server
    frame_size = image_size * image_size * 4  # RGBA bytes
    response_size = 12  # 3 floats
    
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(('', args.port))
    server.listen(1)
    
    print(f"\nInference server listening on port {args.port}")
    print("Waiting for Unity connection...")
    
    while True:
        client, addr = server.accept()
        client.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        print(f"Client connected from {addr}")
        
        inference_count = 0
        start_time = time.time()
        
        try:
            while True:
                # Receive image
                data = b''
                while len(data) < frame_size:
                    chunk = client.recv(frame_size - len(data))
                    if not chunk:
                        raise ConnectionError("Client disconnected")
                    data += chunk
                
                # Parse image
                pixels = np.frombuffer(data, dtype=np.uint8)
                pixels = pixels.reshape(image_size, image_size, 4)
                pixels = pixels.astype(np.float32) / 255.0
                image = np.transpose(pixels, (2, 0, 1))
                
                # To tensor
                image_tensor = torch.from_numpy(image).unsqueeze(0).to(device)
                
                # Inference
                with torch.no_grad():
                    prediction = model(image_tensor)
                
                # Extract rotation values
                rx, ry, rz = prediction[0].cpu().numpy()
                
                # Send response
                response = struct.pack('<fff', rx, ry, rz)
                client.send(response)
                
                inference_count += 1
                
                if inference_count % 1000 == 0:
                    elapsed = time.time() - start_time
                    fps = inference_count / elapsed
                    print(f"  Inferences: {inference_count:,} | FPS: {fps:.1f}")
        
        except ConnectionError:
            print(f"Client disconnected after {inference_count} inferences")
        
        finally:
            client.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Inverse pose inference server')
    parser.add_argument('--model', required=True, help='Path to trained model')
    parser.add_argument('--port', type=int, default=5556, help='Server port')
    parser.add_argument('--image_size', type=int, default=128, help='Image size (fallback)')
    
    args = parser.parse_args()
    serve(args)
