// SpatialAffectTrainingBridge.cs
// Streams framebuffer + rotation labels directly to Python for training
// No disk I/O — GPU → training loop

using UnityEngine;
using UnityEngine.Rendering;
using Unity.Collections;
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Concurrent;

public class SpatialAffectTrainingBridge : MonoBehaviour
{
    [Header("References")]
    public ComputeShader spatialAffectCompute;
    public Camera targetCamera;

    [Header("Settings")]
    public int gridSize = 256;
    public int imageSize = 128; // Use quarter res for training speed
    public int port = 5555;
    public bool randomSampling = true; // Random rotations vs sequential

    [Header("Stats")]
    public long framesSent = 0;
    public float fps = 0f;
    public bool connected = false;

    // GPU resources
    private RenderTexture renderTarget;
    private ComputeBuffer depthBuffer;
    private int kernelMain;
    private int kernelClear;

    // Networking
    private TcpListener listener;
    private TcpClient client;
    private NetworkStream stream;
    private Thread listenerThread;
    private volatile bool running = true;

    // Async readback queue
    private ConcurrentQueue<PendingFrame> pendingFrames = new ConcurrentQueue<PendingFrame>();
    private byte[] sendBuffer;

    // Current rotation
    private Vector3 currentRotation;
    private System.Random rng = new System.Random();

    private struct PendingFrame
    {
        public Vector3 rotation;
        public AsyncGPUReadbackRequest request;
    }

    void Start()
    {
        if (targetCamera == null)
            targetCamera = Camera.main;

        InitializeGPU();
        InitializeNetworking();

        // Buffer: 3 floats (rotation) + imageSize² * 4 bytes (RGBA)
        sendBuffer = new byte[12 + imageSize * imageSize * 4];
    }

    void InitializeGPU()
    {
        renderTarget = new RenderTexture(imageSize, imageSize, 0, RenderTextureFormat.ARGB32);
        renderTarget.enableRandomWrite = true;
        renderTarget.filterMode = FilterMode.Point;
        renderTarget.Create();

        depthBuffer = new ComputeBuffer(imageSize * imageSize, sizeof(uint));

        kernelMain = spatialAffectCompute.FindKernel("CSMain");
        kernelClear = spatialAffectCompute.FindKernel("CSClear");

        // Bind resources (uses SpatialAffectTraining.compute)
        spatialAffectCompute.SetTexture(kernelMain, "Result", renderTarget);
        spatialAffectCompute.SetBuffer(kernelMain, "DepthBuffer", depthBuffer);
        spatialAffectCompute.SetBuffer(kernelClear, "DepthBuffer", depthBuffer);

        // Set constants
        spatialAffectCompute.SetInt("GridSize", gridSize);
        spatialAffectCompute.SetInt("ImageSize", imageSize);
    }

    void InitializeNetworking()
    {
        listenerThread = new Thread(ListenForClient);
        listenerThread.IsBackground = true;
        listenerThread.Start();
    }

    void ListenForClient()
    {
        try
        {
            listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            Debug.Log($"[TrainingBridge] Listening on port {port}...");

            while (running)
            {
                if (listener.Pending())
                {
                    client = listener.AcceptTcpClient();
                    client.NoDelay = true;
                    stream = client.GetStream();
                    connected = true;
                    Debug.Log("[TrainingBridge] Python training process connected!");
                }
                Thread.Sleep(100);
            }
        }
        catch (Exception e)
        {
            if (running)
                Debug.LogError($"[TrainingBridge] Network error: {e.Message}");
        }
    }

    void Update()
    {
        if (!connected)
            return;

        // Process completed readbacks
        ProcessPendingFrames();

        // Generate new frame
        RenderAndRequestReadback();

        // Stats
        fps = 1f / Time.deltaTime;
    }

    void RenderAndRequestReadback()
    {
        // Pick rotation
        if (randomSampling)
        {
            currentRotation = new Vector3(
                (float)rng.NextDouble() * 256f,
                (float)rng.NextDouble() * 256f,
                (float)rng.NextDouble() * 256f
            );
        }
        else
        {
            // Sequential — but this is slower for training convergence
            currentRotation.z += 1f;
            if (currentRotation.z >= 256f)
            {
                currentRotation.z = 0f;
                currentRotation.y += 1f;
                if (currentRotation.y >= 256f)
                {
                    currentRotation.y = 0f;
                    currentRotation.x += 1f;
                    if (currentRotation.x >= 256f)
                        currentRotation.x = 0f;
                }
            }
        }

        // Apply rotation to camera
        float angleStep = 360f / 255f;
        targetCamera.transform.rotation = Quaternion.Euler(
            currentRotation.x * angleStep,
            currentRotation.y * angleStep,
            currentRotation.z * angleStep
        );

        // Clear
        ClearRenderTarget();

        // Dispatch compute shader
        Matrix4x4 vp = targetCamera.projectionMatrix * targetCamera.worldToCameraMatrix;
        spatialAffectCompute.SetMatrix("ViewProjectionMatrix", vp);
        spatialAffectCompute.SetVector("CameraPosition", targetCamera.transform.position);
        spatialAffectCompute.SetVector("CameraForward", targetCamera.transform.forward);

        int clearThreads = Mathf.CeilToInt(imageSize * imageSize / 64f);
        spatialAffectCompute.Dispatch(kernelClear, clearThreads, 1, 1);

        int threadGroups = Mathf.CeilToInt(gridSize / 8f);
        spatialAffectCompute.Dispatch(kernelMain, threadGroups, threadGroups, threadGroups);

        // Request async readback
        var request = AsyncGPUReadback.Request(renderTarget);
        pendingFrames.Enqueue(new PendingFrame
        {
            rotation = currentRotation,
            request = request
        });
    }

    void ClearRenderTarget()
    {
        RenderTexture rt = RenderTexture.active;
        RenderTexture.active = renderTarget;
        GL.Clear(true, true, Color.clear);
        RenderTexture.active = rt;
    }

    void ProcessPendingFrames()
    {
        while (pendingFrames.TryPeek(out PendingFrame frame))
        {
            if (frame.request.hasError)
            {
                pendingFrames.TryDequeue(out _);
                continue;
            }

            if (!frame.request.done)
                break;

            pendingFrames.TryDequeue(out _);

            // Get pixel data
            NativeArray<byte> pixels = frame.request.GetData<byte>();

            // Pack into send buffer
            // First 12 bytes: rotation (x, y, z) as floats normalized to 0-1
            float rx = frame.rotation.x / 255f;
            float ry = frame.rotation.y / 255f;
            float rz = frame.rotation.z / 255f;

            Buffer.BlockCopy(BitConverter.GetBytes(rx), 0, sendBuffer, 0, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(ry), 0, sendBuffer, 4, 4);
            Buffer.BlockCopy(BitConverter.GetBytes(rz), 0, sendBuffer, 8, 4);

            // Remaining bytes: pixel data
            pixels.CopyTo(sendBuffer.AsSpan(12).ToArray());

            // Actually copy properly
            var pixelArray = pixels.ToArray();
            Buffer.BlockCopy(pixelArray, 0, sendBuffer, 12, pixelArray.Length);

            // Send to Python
            try
            {
                stream.Write(sendBuffer, 0, sendBuffer.Length);
                framesSent++;
            }
            catch (Exception)
            {
                connected = false;
                Debug.Log("[TrainingBridge] Client disconnected");
            }
        }
    }

    void OnDestroy()
    {
        running = false;

        stream?.Close();
        client?.Close();
        listener?.Stop();
        listenerThread?.Join(1000);

        renderTarget?.Release();
        depthBuffer?.Release();
    }

    void OnGUI()
    {
        GUILayout.BeginArea(new Rect(10, 10, 300, 100));
        GUILayout.Label($"Status: {(connected ? "TRAINING" : "Waiting for Python...")}");
        GUILayout.Label($"Frames sent: {framesSent:N0}");
        GUILayout.Label($"FPS: {fps:F1}");
        GUILayout.Label($"Rotation: {currentRotation}");
        GUILayout.EndArea();
    }
}
