# SpatialAffect Inverse Pose Estimator

Train a neural network to predict camera rotation from voxel projection images — no disk I/O, direct framebuffer to training loop.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        TRAINING                             │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Unity                          Python                      │
│  ┌──────────────────┐          ┌──────────────────────┐    │
│  │ SpatialAffect    │   TCP    │ inverse_pose_        │    │
│  │ TrainingBridge   │ ──────▶  │ trainer.py           │    │
│  └──────────────────┘          └──────────────────────┘    │
│         │                               │                   │
│         ▼                               ▼                   │
│  ┌──────────────────┐          ┌──────────────────────┐    │
│  │ Compute Shader   │          │ InversePoseNet (CNN) │    │
│  │ (voxel render)   │          │ + backprop           │    │
│  └──────────────────┘          └──────────────────────┘    │
│                                         │                   │
│                                         ▼                   │
│                                  inverse_pose_final.pt     │
└─────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────┐
│                        INFERENCE                            │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  Unity                          Python                      │
│  ┌──────────────────┐          ┌──────────────────────┐    │
│  │ InversePose      │   TCP    │ inverse_pose_        │    │
│  │ Client           │ ◀──────▶ │ server.py            │    │
│  └──────────────────┘          └──────────────────────┘    │
│         │                               │                   │
│         ▼                               ▼                   │
│  predictedEulerAngles         inverse_pose_final.pt        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Files

### Unity (C#)
- `SpatialAffectTrainingBridge.cs` - Renders frames and streams to Python
- `SpatialAffectTraining.compute` - Simplified compute shader for training
- `InversePoseClient.cs` - Queries trained model during gameplay

### Python
- `inverse_pose_trainer.py` - Receives frames, trains CNN
- `inverse_pose_server.py` - Serves trained model for inference

## Training

### 1. Setup Unity
1. Create empty GameObject, attach `SpatialAffectTrainingBridge`
2. Assign compute shader `SpatialAffectTraining.compute`
3. Configure `gridSize` and `imageSize` (128 recommended for training speed)
4. Play scene

### 2. Start Training
```bash
pip install torch numpy

python inverse_pose_trainer.py \
    --host localhost \
    --port 5555 \
    --image_size 128 \
    --batch_size 32 \
    --lr 0.001 \
    --iterations 100000
```

Training will automatically connect to Unity and begin.

### 3. Monitor Progress
```
[  1000] Loss: 0.012345 | Error: 5.23° | FPS: 245.3 | LR: 0.001000
[  2000] Loss: 0.008123 | Error: 3.87° | FPS: 248.1 | LR: 0.000999
...
```

## Inference

### 1. Start Server
```bash
python inverse_pose_server.py --model inverse_pose_final.pt --port 5556
```

### 2. Unity Client
```csharp
public class MyGame : MonoBehaviour
{
    public InversePoseClient poseEstimator;
    public RenderTexture observedImage; // From a secondary camera, sensor, etc.
    
    void Update()
    {
        // Feed observed image
        poseEstimator.inputTexture = observedImage;
        
        // Request estimation
        poseEstimator.RequestPoseEstimationAsync();
        
        // Use result
        Debug.Log($"Estimated rotation: {poseEstimator.predictedEulerAngles}");
    }
}
```

## Use Cases

| Application | Description |
|-------------|-------------|
| Pose estimation | Recover camera orientation from partial observations |
| Visual localization | "Where am I looking?" from an image |
| Inverse graphics | Differentiable path from image → scene parameters |
| Anomaly detection | Compare predicted vs actual camera pose |

## Training Tips

- **Random sampling** (default) converges faster than sequential
- **128×128** is fastest for training; use 256 or 512 for production accuracy
- **100k iterations** with batch 32 ≈ 1-2 hours on modern GPU
- **Circular loss** handles 0°/360° wraparound correctly
- **Final error** should be <2° for practical use

## Network Architecture

```
Input:  [B, 4, 128, 128] — RGBA (RGB=world coords, A=depth)
        ↓
Conv1:  [B, 32, 64, 64]  — 5×5, stride 2, LeakyReLU, BatchNorm
Conv2:  [B, 64, 32, 32]  — 5×5, stride 2, LeakyReLU, BatchNorm
Conv3:  [B, 128, 16, 16] — 3×3, stride 2, LeakyReLU, BatchNorm
Conv4:  [B, 256, 8, 8]   — 3×3, stride 2, LeakyReLU, BatchNorm
Conv5:  [B, 512, 4, 4]   — 3×3, stride 2, LeakyReLU, BatchNorm
        ↓
GlobalAvgPool → [B, 512]
        ↓
FC1:    [B, 256] + Dropout(0.3)
FC2:    [B, 128] + Dropout(0.3)
FC3:    [B, 3]   + Sigmoid
        ↓
Output: [B, 3] — rotation (x, y, z) normalized 0-1
```

## Performance

| Stage | Time |
|-------|------|
| GPU render | ~2 ms |
| AsyncGPUReadback | ~3 ms |
| TCP transfer | ~1 ms |
| Inference | ~2 ms |
| **Total roundtrip** | **~8 ms** |

Training throughput: ~200-300 FPS depending on GPU/network.
