// InversePoseClient.cs
// Sends rendered frames to Python inference server, receives predicted rotation
// Use after training to estimate camera pose from observed images

using UnityEngine;
using UnityEngine.Rendering;
using Unity.Collections;
using System;
using System.Net.Sockets;
using System.Threading;
using System.Collections.Concurrent;

public class InversePoseClient : MonoBehaviour
{
    [Header("Network Settings")]
    public string serverHost = "localhost";
    public int serverPort = 5556;

    [Header("Image Settings")]
    public int imageSize = 128;

    [Header("Input")]
    public RenderTexture inputTexture; // The image to estimate pose from

    [Header("Output (Read-Only)")]
    public Vector3 predictedRotation;
    public Vector3 predictedEulerAngles;
    public float inferenceTimeMs;
    public bool isConnected;

    // Networking
    private TcpClient client;
    private NetworkStream stream;
    private Thread networkThread;
    private volatile bool running = true;

    // Async communication
    private ConcurrentQueue<byte[]> sendQueue = new ConcurrentQueue<byte[]>();
    private ConcurrentQueue<Vector3> receiveQueue = new ConcurrentQueue<Vector3>();

    // Buffers
    private byte[] sendBuffer;
    private byte[] receiveBuffer;
    private Texture2D readbackTexture;

    // Timing
    private float lastSendTime;

    void Start()
    {
        sendBuffer = new byte[imageSize * imageSize * 4];
        receiveBuffer = new byte[12];
        readbackTexture = new Texture2D(imageSize, imageSize, TextureFormat.RGBA32, false);

        // Create default input texture if not assigned
        if (inputTexture == null)
        {
            inputTexture = new RenderTexture(imageSize, imageSize, 0, RenderTextureFormat.ARGB32);
            inputTexture.enableRandomWrite = true;
            inputTexture.filterMode = FilterMode.Point;
            inputTexture.Create();
        }

        // Start network thread
        networkThread = new Thread(NetworkLoop);
        networkThread.IsBackground = true;
        networkThread.Start();
    }

    void NetworkLoop()
    {
        while (running)
        {
            // Try to connect
            while (running && !isConnected)
            {
                try
                {
                    client = new TcpClient();
                    client.Connect(serverHost, serverPort);
                    client.NoDelay = true;
                    stream = client.GetStream();
                    isConnected = true;
                    Debug.Log($"[InversePoseClient] Connected to {serverHost}:{serverPort}");
                }
                catch (Exception)
                {
                    Thread.Sleep(1000);
                }
            }

            // Process queue
            while (running && isConnected)
            {
                try
                {
                    // Send pending frames
                    if (sendQueue.TryDequeue(out byte[] data))
                    {
                        stream.Write(data, 0, data.Length);

                        // Wait for response
                        int bytesRead = 0;
                        while (bytesRead < 12)
                        {
                            bytesRead += stream.Read(receiveBuffer, bytesRead, 12 - bytesRead);
                        }

                        // Parse rotation
                        float rx = BitConverter.ToSingle(receiveBuffer, 0);
                        float ry = BitConverter.ToSingle(receiveBuffer, 4);
                        float rz = BitConverter.ToSingle(receiveBuffer, 8);

                        receiveQueue.Enqueue(new Vector3(rx, ry, rz));
                    }
                    else
                    {
                        Thread.Sleep(1);
                    }
                }
                catch (Exception e)
                {
                    Debug.Log($"[InversePoseClient] Connection lost: {e.Message}");
                    isConnected = false;
                    client?.Close();
                }
            }
        }
    }

    void Update()
    {
        // Process received predictions
        while (receiveQueue.TryDequeue(out Vector3 rotation))
        {
            predictedRotation = rotation;

            // Convert normalized 0-1 to degrees
            float angleStep = 360f / 255f;
            predictedEulerAngles = new Vector3(
                rotation.x * 255f * angleStep,
                rotation.y * 255f * angleStep,
                rotation.z * 255f * angleStep
            );

            inferenceTimeMs = (Time.time - lastSendTime) * 1000f;
        }
    }

    /// <summary>
    /// Request pose estimation for the current input texture.
    /// Result will be available in predictedRotation/predictedEulerAngles next frame.
    /// </summary>
    public void RequestPoseEstimation()
    {
        if (!isConnected)
            return;

        // Readback texture
        RenderTexture.active = inputTexture;
        readbackTexture.ReadPixels(new Rect(0, 0, imageSize, imageSize), 0, 0);
        readbackTexture.Apply();
        RenderTexture.active = null;

        // Get pixel data
        Color32[] pixels = readbackTexture.GetPixels32();

        // Pack into buffer (RGBA format)
        for (int i = 0; i < pixels.Length; i++)
        {
            sendBuffer[i * 4 + 0] = pixels[i].r;
            sendBuffer[i * 4 + 1] = pixels[i].g;
            sendBuffer[i * 4 + 2] = pixels[i].b;
            sendBuffer[i * 4 + 3] = pixels[i].a;
        }

        // Queue for sending
        byte[] copy = new byte[sendBuffer.Length];
        Buffer.BlockCopy(sendBuffer, 0, copy, 0, sendBuffer.Length);
        sendQueue.Enqueue(copy);

        lastSendTime = Time.time;
    }

    /// <summary>
    /// Request pose estimation using AsyncGPUReadback (non-blocking).
    /// </summary>
    public void RequestPoseEstimationAsync()
    {
        if (!isConnected)
            return;

        AsyncGPUReadback.Request(inputTexture, 0, TextureFormat.RGBA32, OnReadbackComplete);
        lastSendTime = Time.time;
    }

    private void OnReadbackComplete(AsyncGPUReadbackRequest request)
    {
        if (request.hasError)
            return;

        NativeArray<byte> pixels = request.GetData<byte>();

        byte[] copy = new byte[pixels.Length];
        pixels.CopyTo(copy);
        sendQueue.Enqueue(copy);
    }

    /// <summary>
    /// Apply predicted rotation to a transform.
    /// </summary>
    public void ApplyPredictedRotation(Transform target)
    {
        target.rotation = Quaternion.Euler(predictedEulerAngles);
    }

    void OnDestroy()
    {
        running = false;
        client?.Close();
        networkThread?.Join(1000);
    }

    void OnGUI()
    {
        GUILayout.BeginArea(new Rect(10, 120, 300, 100));
        GUILayout.Label($"Pose Estimator: {(isConnected ? "Connected" : "Disconnected")}");
        GUILayout.Label($"Predicted: ({predictedEulerAngles.x:F1}°, {predictedEulerAngles.y:F1}°, {predictedEulerAngles.z:F1}°)");
        GUILayout.Label($"Inference: {inferenceTimeMs:F1}ms");
        GUILayout.EndArea();
    }
}
