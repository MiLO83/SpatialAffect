#!/usr/bin/env python3
"""
SpatialAffect Inverse Pose Estimator
Learns: image → camera rotation

Receives rendered frames from Unity over TCP, trains CNN to predict
the camera rotation that produced each image.

Usage:
    python inverse_pose_trainer.py [--host localhost] [--port 5555]
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler
import numpy as np
import socket
import struct
import argparse
import time
from collections import deque


class InversePoseNet(nn.Module):
    """
    CNN that predicts camera rotation from voxel projection image.
    
    Input: [B, 4, H, W] - RGBA image (RGB=world coords, A=depth)
    Output: [B, 3] - rotation (x, y, z) normalized 0-1
    """
    
    def __init__(self, image_size=128):
        super().__init__()
        
        # Encoder - extract spatial features
        self.conv1 = nn.Conv2d(4, 32, 5, stride=2, padding=2)   # -> 64
        self.conv2 = nn.Conv2d(32, 64, 5, stride=2, padding=2)  # -> 32
        self.conv3 = nn.Conv2d(64, 128, 3, stride=2, padding=1) # -> 16
        self.conv4 = nn.Conv2d(128, 256, 3, stride=2, padding=1) # -> 8
        self.conv5 = nn.Conv2d(256, 512, 3, stride=2, padding=1) # -> 4
        
        self.bn1 = nn.BatchNorm2d(32)
        self.bn2 = nn.BatchNorm2d(64)
        self.bn3 = nn.BatchNorm2d(128)
        self.bn4 = nn.BatchNorm2d(256)
        self.bn5 = nn.BatchNorm2d(512)
        
        # Global pooling + FC layers
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        
        self.fc1 = nn.Linear(512, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 3)
        
        self.dropout = nn.Dropout(0.3)
    
    def forward(self, x):
        # Conv blocks with residual-ish structure
        x = F.leaky_relu(self.bn1(self.conv1(x)), 0.2)
        x = F.leaky_relu(self.bn2(self.conv2(x)), 0.2)
        x = F.leaky_relu(self.bn3(self.conv3(x)), 0.2)
        x = F.leaky_relu(self.bn4(self.conv4(x)), 0.2)
        x = F.leaky_relu(self.bn5(self.conv5(x)), 0.2)
        
        # Global pool -> flatten
        x = self.global_pool(x)
        x = x.view(x.size(0), -1)
        
        # FC layers
        x = F.leaky_relu(self.fc1(x), 0.2)
        x = self.dropout(x)
        x = F.leaky_relu(self.fc2(x), 0.2)
        x = self.dropout(x)
        x = self.fc3(x)
        
        # Sigmoid to bound output 0-1
        x = torch.sigmoid(x)
        
        return x


class CircularLoss(nn.Module):
    """
    Loss function that handles angular wraparound.
    0.0 and 1.0 should be close (they represent 0° and 360°).
    """
    
    def forward(self, pred, target):
        # Compute both direct distance and wraparound distance
        diff = torch.abs(pred - target)
        wrap_diff = 1.0 - diff
        
        # Take minimum of direct and wraparound
        angular_diff = torch.min(diff, wrap_diff)
        
        return torch.mean(angular_diff ** 2)


class UnityFrameReceiver:
    """Receives rendered frames from Unity over TCP."""
    
    def __init__(self, host='localhost', port=5555, image_size=128):
        self.host = host
        self.port = port
        self.image_size = image_size
        self.frame_size = 12 + image_size * image_size * 4  # 3 floats + RGBA
        self.socket = None
    
    def connect(self):
        print(f"Connecting to Unity at {self.host}:{self.port}...")
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect((self.host, self.port))
        self.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        print("Connected!")
    
    def receive_frame(self):
        """Receive one frame: rotation + image."""
        data = b''
        while len(data) < self.frame_size:
            chunk = self.socket.recv(self.frame_size - len(data))
            if not chunk:
                raise ConnectionError("Unity disconnected")
            data += chunk
        
        # Parse rotation (3 floats, little-endian)
        rx, ry, rz = struct.unpack('<fff', data[:12])
        rotation = np.array([rx, ry, rz], dtype=np.float32)
        
        # Parse image (RGBA bytes -> float tensor)
        pixels = np.frombuffer(data[12:], dtype=np.uint8)
        pixels = pixels.reshape(self.image_size, self.image_size, 4)
        pixels = pixels.astype(np.float32) / 255.0
        
        # Convert to CHW format
        image = np.transpose(pixels, (2, 0, 1))
        
        return rotation, image
    
    def receive_batch(self, batch_size):
        """Receive multiple frames for batched training."""
        rotations = []
        images = []
        
        for _ in range(batch_size):
            rot, img = self.receive_frame()
            rotations.append(rot)
            images.append(img)
        
        return np.stack(rotations), np.stack(images)
    
    def close(self):
        if self.socket:
            self.socket.close()


def train(args):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"Using device: {device}")
    
    # Initialize model
    model = InversePoseNet(args.image_size).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.iterations)
    criterion = CircularLoss()
    scaler = GradScaler()
    
    # Connect to Unity
    receiver = UnityFrameReceiver(args.host, args.port, args.image_size)
    receiver.connect()
    
    # Training stats
    losses = deque(maxlen=100)
    errors = deque(maxlen=100)
    start_time = time.time()
    frames_received = 0
    
    print("\n" + "="*60)
    print("TRAINING INVERSE POSE ESTIMATOR")
    print("="*60)
    print(f"Image size: {args.image_size}x{args.image_size}")
    print(f"Batch size: {args.batch_size}")
    print(f"Learning rate: {args.lr}")
    print("="*60 + "\n")
    
    try:
        for iteration in range(args.iterations):
            # Receive batch from Unity
            rot_np, img_np = receiver.receive_batch(args.batch_size)
            frames_received += args.batch_size
            
            # To tensors
            images = torch.from_numpy(img_np).to(device)
            targets = torch.from_numpy(rot_np).to(device)
            
            # Forward pass with mixed precision
            optimizer.zero_grad()
            with autocast():
                predictions = model(images)
                loss = criterion(predictions, targets)
            
            # Backward pass
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            
            # Compute angular error in degrees
            with torch.no_grad():
                diff = torch.abs(predictions - targets)
                wrap_diff = 1.0 - diff
                angular_diff = torch.min(diff, wrap_diff)
                error_degrees = angular_diff.mean() * 360.0 / 255.0 * 255.0  # Convert to degrees
            
            losses.append(loss.item())
            errors.append(error_degrees.item())
            
            # Log progress
            if iteration % 100 == 0:
                elapsed = time.time() - start_time
                fps = frames_received / elapsed
                avg_loss = np.mean(losses)
                avg_error = np.mean(errors)
                
                print(f"[{iteration:6d}] Loss: {avg_loss:.6f} | "
                      f"Error: {avg_error:.2f}° | "
                      f"FPS: {fps:.1f} | "
                      f"LR: {scheduler.get_last_lr()[0]:.6f}")
            
            # Save checkpoint
            if iteration > 0 and iteration % args.save_every == 0:
                checkpoint = {
                    'iteration': iteration,
                    'model_state': model.state_dict(),
                    'optimizer_state': optimizer.state_dict(),
                    'loss': np.mean(losses),
                }
                torch.save(checkpoint, f'inverse_pose_checkpoint_{iteration}.pt')
                print(f"  → Saved checkpoint at iteration {iteration}")
    
    except KeyboardInterrupt:
        print("\n\nTraining interrupted by user")
    
    except ConnectionError as e:
        print(f"\n\nConnection lost: {e}")
    
    finally:
        receiver.close()
        
        # Save final model
        torch.save({
            'model_state': model.state_dict(),
            'image_size': args.image_size,
        }, 'inverse_pose_final.pt')
        print(f"\nSaved final model to inverse_pose_final.pt")
        
        # Print final stats
        elapsed = time.time() - start_time
        print(f"\nTraining complete:")
        print(f"  Frames processed: {frames_received:,}")
        print(f"  Time elapsed: {elapsed:.1f}s")
        print(f"  Average FPS: {frames_received/elapsed:.1f}")
        print(f"  Final loss: {np.mean(losses):.6f}")
        print(f"  Final error: {np.mean(errors):.2f}°")


def test_inference(model_path, image_size=128):
    """Load trained model and run inference on test images."""
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Load model
    checkpoint = torch.load(model_path, map_location=device)
    model = InversePoseNet(image_size).to(device)
    model.load_state_dict(checkpoint['model_state'])
    model.eval()
    
    print(f"Model loaded from {model_path}")
    print(f"Ready for inference at {image_size}x{image_size}")
    
    return model


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Train inverse pose estimator')
    parser.add_argument('--host', default='localhost', help='Unity host')
    parser.add_argument('--port', type=int, default=5555, help='Unity port')
    parser.add_argument('--image_size', type=int, default=128, help='Image size')
    parser.add_argument('--batch_size', type=int, default=32, help='Batch size')
    parser.add_argument('--lr', type=float, default=1e-3, help='Learning rate')
    parser.add_argument('--iterations', type=int, default=100000, help='Training iterations')
    parser.add_argument('--save_every', type=int, default=10000, help='Save checkpoint every N iterations')
    
    args = parser.parse_args()
    train(args)
